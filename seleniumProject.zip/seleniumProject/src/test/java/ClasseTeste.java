/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
/**
 *
 * @author Aluno
 */
public class ClasseTeste {
    static WebDriver driver;
 
    
    @BeforeClass
    public static void configurar(){
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("http://www.google.com.br");
        
    }
    
    @Test
    public  void executeTeste(){
        System.out.println("Teste");
        for (int i = 1; i < 100; i++){
            String e = Integer.toString(i);
            WebElement input = driver.findElement(By.name("q"));
            input.sendKeys(e);
            WebElement selenium = driver.findElement(By.name("btnK"));
            selenium.submit();
            driver.navigate().back();
        }
        
    }
    
}
